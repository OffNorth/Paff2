"""
Phase 2 — Entraînement d'un modèle simple (régression logistique, implémentée
sans dépendance externe) prédisant P(le token atteint x2) à partir des mêmes
features que backtest/pattern_compare.py.

⚠️ Volontairement PAS branché sur le scoring tant qu'il n'y a pas assez de
données : voir MIN_SAMPLES ci-dessous. Le brief du projet est explicite —
"Ne pas ajouter du machine learning artificiel juste pour faire joli."
Ce module ne s'active donc que si tu as accumulé un historique de calls
fermés suffisant pour qu'un entraînement ait un sens.

Usage :
    python -m ml.train
Écrit ml/model.json si assez de données, sinon explique combien il en manque.
"""
import asyncio
import json
import math
import random

from database.database import Database
from backtest.pattern_compare import FEATURES

MIN_SAMPLES = 200  # seuil minimal avant d'envisager un entraînement
SUCCESS_MULTIPLE = 2.0  # "succès" = a atteint au moins x2
EPOCHS = 500
LR = 0.05


def _normalize(vectors: list[list[float]]) -> tuple[list[list[float]], list[float], list[float]]:
    n_feat = len(vectors[0])
    mins = [min(v[i] for v in vectors) for i in range(n_feat)]
    maxs = [max(v[i] for v in vectors) for i in range(n_feat)]
    norm = []
    for v in vectors:
        row = []
        for i in range(n_feat):
            span = maxs[i] - mins[i] or 1.0
            row.append((v[i] - mins[i]) / span)
        norm.append(row)
    return norm, mins, maxs


def _sigmoid(z: float) -> float:
    z = max(-30, min(30, z))
    return 1 / (1 + math.exp(-z))


def _train_logistic(X: list[list[float]], y: list[int]) -> list[float]:
    n_feat = len(X[0])
    weights = [0.0] * (n_feat + 1)  # +1 pour le biais
    n = len(X)
    for _ in range(EPOCHS):
        grad = [0.0] * (n_feat + 1)
        for xi, yi in zip(X, y):
            z = weights[0] + sum(w * x for w, x in zip(weights[1:], xi))
            pred = _sigmoid(z)
            err = pred - yi
            grad[0] += err
            for j, x in enumerate(xi):
                grad[j + 1] += err * x
        for j in range(len(weights)):
            weights[j] -= LR * grad[j] / n
    return weights


async def main():
    db = Database("memecoin_bot.db")
    await db.connect()
    closed = await db.all_closed_calls_full()
    await db.close()

    samples = [c for c in closed if c.get("entry_features")]
    if len(samples) < MIN_SAMPLES:
        print(f"⛔ Pas assez de données pour entraîner un modèle fiable : "
              f"{len(samples)}/{MIN_SAMPLES} calls fermés avec features disponibles.")
        print("Continue à faire tourner le bot pour accumuler de l'historique — "
              "aucun modèle n'est activé tant que ce seuil n'est pas atteint.")
        return

    random.shuffle(samples)
    X = [[float(s["entry_features"].get(f, 0) or 0) for f in FEATURES] for s in samples]
    y = [1 if (s.get("peak_multiple") or 0) >= SUCCESS_MULTIPLE else 0 for s in samples]

    X_norm, mins, maxs = _normalize(X)
    weights = _train_logistic(X_norm, y)

    # Split simple pour un indicateur de qualité approximatif (pas une vraie validation croisée)
    split = int(len(X_norm) * 0.8)
    correct = 0
    for xi, yi in zip(X_norm[split:], y[split:]):
        z = weights[0] + sum(w * x for w, x in zip(weights[1:], xi))
        pred = 1 if _sigmoid(z) >= 0.5 else 0
        correct += int(pred == yi)
    holdout_acc = correct / max(1, len(y) - split)

    model = {"features": FEATURES, "weights": weights, "mins": mins, "maxs": maxs,
             "trained_on": len(samples), "holdout_accuracy": round(holdout_acc, 3),
             "success_multiple": SUCCESS_MULTIPLE}
    with open("ml/model.json", "w", encoding="utf-8") as f:
        json.dump(model, f, indent=2)

    print(f"✅ Modèle entraîné sur {len(samples)} calls. Précision holdout approx.: {holdout_acc:.1%}")
    print("Écrit dans ml/model.json. Active-le dans config.json (\"ml\": {\"enabled\": true}) pour "
          "l'utiliser comme signal d'appoint dans le score.")


if __name__ == "__main__":
    asyncio.run(main())
