"""Combine les sous-scores market + social en un score total configurable."""
from scoring import momentum


class TokenScorer:
    def __init__(self, weights: dict):
        self.w = weights

    def score(self, market: dict, social: dict) -> dict:
        p = momentum.price_momentum_score(market)
        v = momentum.volume_score(market)
        bs = momentum.buyers_sellers_score(market)
        hg = momentum.holder_growth_score(market)
        liq = momentum.liquidity_score(market)
        wa = momentum.wallet_activity_score(market)
        so = social.get("social_score", 0)
        sa = social.get("social_acceleration", 0)
        combined_social = so * 0.6 + sa * 0.4

        total = (
            p * self.w["price_momentum"] / 100
            + v * self.w["volume"] / 100
            + bs * self.w["buyers_sellers"] / 100
            + hg * self.w["holder_growth"] / 100
            + liq * self.w["liquidity"] / 100
            + wa * self.w["wallet_activity"] / 100
            + combined_social * self.w["social_momentum"] / 100
        )
        return {
            "price_momentum": round(p, 1),
            "volume": round(v, 1),
            "buyers_sellers": round(bs, 1),
            "holder_growth": round(hg, 1),
            "liquidity": round(liq, 1),
            "wallet_activity": round(wa, 1),
            "social_momentum": round(combined_social, 1),
            "social_score": round(so, 1),
            "social_acceleration": round(sa, 1),
            "total": round(min(total, 100), 1),
        }


def level_for_score(total: float, thresholds: dict) -> str | None:
    if total >= thresholds.get("strong", 85):
        return "STRONG"
    if total >= thresholds.get("potential", 75):
        return "POTENTIAL"
    if total >= thresholds.get("watch", 65):
        return "WATCH"
    return None
