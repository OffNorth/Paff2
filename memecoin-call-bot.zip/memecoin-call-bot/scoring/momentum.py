"""Calcul des sous-scores 'market' (momentum prix, volume, buyers/sellers, holders, liquidité, wallet)."""
import math


def price_momentum_score(m: dict) -> float:
    c5 = m.get("price_change_5m", 0)
    c1h = m.get("price_change_1h", 0)
    accel = c5 - (c1h / 12) if c1h else c5
    s = 100 / (1 + math.exp(-0.1 * accel))
    if c5 < 0:
        s *= max(0.1, 1 + c5 / 50)
    return max(0, min(s, 100))


def volume_score(m: dict) -> float:
    v5 = m.get("volume_5m", 0)
    mc = m.get("market_cap", 1) or 1
    liq = m.get("liquidity_usd", 1) or 1
    return max(0, min(100, (v5 / mc) * 50 + (v5 / liq) * 20))


def buyers_sellers_score(m: dict) -> float:
    b, s = m.get("buys_5m", 0), m.get("sells_5m", 0)
    t = b + s
    return 0 if t == 0 else min(100, (b / t) * 100)


def holder_growth_score(m: dict) -> float:
    g = m.get("holder_growth_10m", 0)
    return 0 if g <= 0 else min(100, g * 5)


def liquidity_score(m: dict) -> float:
    liq = m.get("liquidity_usd", 0)
    if liq <= 0:
        return 0
    return max(0, min(100, 20 * math.log10(max(liq, 1) / 1000 + 1) + 10))


def wallet_activity_score(m: dict) -> float:
    """
    Phase 2 : si des wallets performants suivis (tracked_wallets.json) ont acheté ce
    token récemment, ce signal prime sur le proxy V1. `smart_wallet_weight` est injecté
    dans le dict market par scanners.wallet_tracker avant l'appel au scorer.
    Sans wallet tracker configuré, retombe sur le proxy V1 (intensité des achats sur 5 min).
    """
    smart_weight = m.get("smart_wallet_weight", 0)
    if smart_weight > 0:
        return min(100, 40 + smart_weight * 20)
    return min(100, m.get("buys_5m", 0) * 2)
