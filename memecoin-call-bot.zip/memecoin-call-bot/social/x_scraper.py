"""
Implémentation de TwitterTracker via twscrape (utilise des comptes X dont
TU possèdes les cookies de session — aucune protection n'est contournée,
c'est un accès authentifié classique).

Ajout d'un compte :
    twscrape add_cookie mon_compte "auth_token=...; ct0=..."

Si twscrape n'est pas installé ou configuré, utilise social.twitter_tracker.NullTracker
à la place — le bot continue de fonctionner sans le volet X.
"""
from datetime import datetime
from social.twitter_tracker import TwitterTracker

try:
    from twscrape import API, gather
    TWSCRAPE_AVAILABLE = True
except ImportError:
    TWSCRAPE_AVAILABLE = False
    API = None
    gather = None


class XScraperTracker(TwitterTracker):
    def __init__(self, accounts_db: str = "x_accounts.db", search_limit: int = 30):
        if not TWSCRAPE_AVAILABLE:
            raise RuntimeError("twscrape non installé. Lance: pip install twscrape")
        self.api = API(accounts_db)
        self.search_limit = search_limit

    async def get_recent_posts(self, accounts: list[str]) -> list[dict]:
        out = []
        for acc in accounts:
            try:
                tweets = await gather(self.api.user_tweets_by_login(acc, limit=10))
                out.extend(self._to_dict(t, acc) for t in tweets)
            except Exception as e:
                print(f"⚠️ X scraper {acc}: {e}")
        return out

    async def search_token_mentions(self, token: str) -> list[dict]:
        if not token:
            return []
        queries = [f"${token} solana", f'"{token}" pump.fun']
        out = []
        for q in queries:
            try:
                tweets = await gather(self.api.search(q, limit=self.search_limit))
                out.extend(self._to_dict(t, t.user.username if t.user else "unknown") for t in tweets)
            except Exception as e:
                print(f"⚠️ X search '{q}': {e}")
        return out

    async def get_account_activity(self, account: str) -> list[dict]:
        return await self.get_recent_posts([account])

    def _to_dict(self, tweet, account: str) -> dict:
        return {
            "id": str(tweet.id),
            "account": account,
            "content": tweet.rawContent,
            "mentioned_at": tweet.date.isoformat() if isinstance(tweet.date, datetime) else str(tweet.date),
            "weight": 1.0,
        }
