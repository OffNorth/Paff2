"""
Interface abstraite pour le tracking X/Twitter.
Permet de brancher n'importe quelle implémentation (scraping de comptes
suivis manuellement, API officielle si disponible, service tiers légal)
sans changer le reste du bot.

⚠️ Ne contourne aucune protection, authentification ou limitation d'un
service tiers. L'implémentation par défaut (NullTracker) ne fait rien tant
qu'aucune source de données X n'est configurée.
"""
from abc import ABC, abstractmethod


class TwitterTracker(ABC):
    @abstractmethod
    async def get_recent_posts(self, accounts: list[str]) -> list[dict]:
        """Retourne les posts récents des comptes suivis."""
        ...

    @abstractmethod
    async def search_token_mentions(self, token: str) -> list[dict]:
        """Retourne les mentions récentes d'un token (cashtag, mint, nom...)."""
        ...

    @abstractmethod
    async def get_account_activity(self, account: str) -> list[dict]:
        """Retourne l'activité récente d'un compte précis."""
        ...


class NullTracker(TwitterTracker):
    """Fallback par défaut quand aucune source X n'est configurée — renvoie des listes vides.
    Le bot reste 100% fonctionnel sans X, avec un social_score toujours à 0."""

    async def get_recent_posts(self, accounts):
        return []

    async def search_token_mentions(self, token):
        return []

    async def get_account_activity(self, account):
        return []
