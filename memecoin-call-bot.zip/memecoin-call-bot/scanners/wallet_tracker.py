"""
Suivi de wallets Solana performants (Phase 2).

Utilise le RPC public Solana (getSignaturesForAddress / getTransaction)
pour détecter si des wallets connus et jugés performants ont acheté un
token tôt après sa création. Aucune API tierce payante requise, mais le
RPC public est rate-limité : pour un usage intensif, utilise un RPC dédié
(Helius, QuickNode...) en changeant SOLANA_RPC_URL dans .env.

⚠️ "Performant" est une étiquette que TU attribues toi-même dans
tracked_wallets.json (ex: wallets qui ont historiquement été tôt sur des
tokens ayant fait x5/x10). Le bot ne devine jamais automatiquement qu'un
wallet est fiable.
"""
import time
import aiohttp
from typing import Optional


class WalletTracker:
    def __init__(self, session: aiohttp.ClientSession, rpc_url: str, wallets: list[dict]):
        self.session = session
        self.rpc_url = rpc_url
        self.wallets = wallets  # [{"address":..., "label":..., "weight":...}]
        self._cache: dict[str, tuple[float, list[str]]] = {}  # mint -> (ts, [labels qui ont acheté]))

    async def _rpc(self, method: str, params: list) -> Optional[dict]:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        try:
            async with self.session.post(self.rpc_url, json=payload, timeout=10) as r:
                if r.status == 200:
                    data = await r.json()
                    return data.get("result")
        except Exception:
            return None
        return None

    async def _wallet_recent_signatures(self, address: str, limit: int = 20) -> list[str]:
        result = await self._rpc("getSignaturesForAddress", [address, {"limit": limit}])
        if not result:
            return []
        return [r["signature"] for r in result]

    async def _tx_mentions_mint(self, signature: str, mint: str) -> bool:
        result = await self._rpc(
            "getTransaction",
            [signature, {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0}],
        )
        if not result:
            return False
        try:
            account_keys = result["transaction"]["message"]["accountKeys"]
            for k in account_keys:
                pk = k.get("pubkey") if isinstance(k, dict) else k
                if pk == mint:
                    return True
            # Vérifie aussi les postTokenBalances (plus fiable pour détecter un swap sur ce mint)
            for bal in result.get("meta", {}).get("postTokenBalances", []) or []:
                if bal.get("mint") == mint:
                    return True
        except Exception:
            return False
        return False

    async def early_buyers_for(self, mint: str) -> dict:
        """Retourne quels wallets suivis ont une transaction récente touchant ce mint."""
        now = time.time()
        cached = self._cache.get(mint)
        if cached and now - cached[0] < 60:
            labels = cached[1]
        else:
            labels = []
            for w in self.wallets:
                sigs = await self._wallet_recent_signatures(w["address"], limit=15)
                for sig in sigs:
                    if await self._tx_mentions_mint(sig, mint):
                        labels.append(w.get("label", w["address"][:6]))
                        break
            self._cache[mint] = (now, labels)

        matched = [w for w in self.wallets if w.get("label", w["address"][:6]) in labels]
        weight_sum = sum(w.get("weight", 1.0) for w in matched)
        return {"smart_wallets_buying": labels, "smart_wallet_weight": weight_sum, "smart_wallet_count": len(labels)}


class NullWalletTracker:
    """Fallback quand aucun wallet n'est configuré — le bot reste fonctionnel sans ce volet."""

    async def early_buyers_for(self, mint: str) -> dict:
        return {"smart_wallets_buying": [], "smart_wallet_weight": 0, "smart_wallet_count": 0}
