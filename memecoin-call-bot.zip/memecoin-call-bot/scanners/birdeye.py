"""
Scanner Birdeye (optionnel) — nécessite une clé API (BIRDEYE_API_KEY).
Sert de source complémentaire/de secours à DexScreener (ex: holder count).
Si aucune clé n'est fournie, ce scanner reste inactif et le bot fonctionne
uniquement avec DexScreener.
"""
import aiohttp
from typing import Optional

BASE = "https://public-api.birdeye.so"


class BirdeyeScanner:
    def __init__(self, session: aiohttp.ClientSession, api_key: str | None):
        self.session = session
        self.api_key = api_key
        self.enabled = bool(api_key)

    def _headers(self) -> dict:
        return {"X-API-KEY": self.api_key or "", "x-chain": "solana"}

    async def get_token_overview(self, mint: str) -> Optional[dict]:
        if not self.enabled:
            return None
        url = f"{BASE}/defi/token_overview?address={mint}"
        try:
            async with self.session.get(url, headers=self._headers(), timeout=10) as r:
                if r.status == 200:
                    payload = await r.json()
                    data = payload.get("data") or {}
                    return {
                        "holders": data.get("holder"),
                        "unique_wallets_24h": data.get("uniqueWallet24h"),
                        "supply": data.get("supply"),
                    }
        except Exception:
            return None
        return None

    async def get_new_listings(self, limit: int = 20) -> list[dict]:
        if not self.enabled:
            return []
        url = f"{BASE}/defi/v2/tokens/new_listing?limit={limit}"
        try:
            async with self.session.get(url, headers=self._headers(), timeout=10) as r:
                if r.status == 200:
                    payload = await r.json()
                    return payload.get("data", {}).get("items", [])
        except Exception:
            return []
        return []
