"""Scanner DexScreener — API publique gratuite, source principale de données market."""
import asyncio
import aiohttp
from typing import Optional

BASE = "https://api.dexscreener.com"


class DexScreenerScanner:
    def __init__(self, session: aiohttp.ClientSession):
        self.session = session
        self._sem = asyncio.Semaphore(8)

    async def get_token_data(self, mint: str) -> Optional[dict]:
        url = f"{BASE}/tokens/v1/solana/{mint}"
        async with self._sem:
            try:
                async with self.session.get(url, timeout=10) as r:
                    if r.status == 200:
                        data = await r.json()
                        return self._parse(data if isinstance(data, dict) else {"pairs": data})
            except (aiohttp.ClientError, asyncio.TimeoutError):
                return None
        return None

    async def search_pairs(self, query: str) -> list[dict]:
        url = f"{BASE}/latest/dex/search?q={query}"
        async with self._sem:
            try:
                async with self.session.get(url, timeout=10) as r:
                    if r.status == 200:
                        return (await r.json()).get("pairs", [])
            except Exception:
                return []
        return []

    async def boosted_tokens(self) -> list[dict]:
        """Tokens récemment boostés — une des sources de discovery de nouveaux tokens."""
        url = f"{BASE}/token-boosts/latest/v1"
        try:
            async with self.session.get(url, timeout=10) as r:
                if r.status == 200:
                    return await r.json()
        except Exception:
            pass
        return []

    def _parse(self, data: dict) -> Optional[dict]:
        pairs = data.get("pairs") or []
        if not pairs:
            return None
        best = max(pairs, key=lambda p: (p.get("liquidity") or {}).get("usd", 0))
        liq = best.get("liquidity") or {}
        vol = best.get("volume") or {}
        pc = best.get("priceChange") or {}
        txns = best.get("txns") or {}
        return {
            "mint": best.get("baseToken", {}).get("address"),
            "symbol": best.get("baseToken", {}).get("symbol"),
            "name": best.get("baseToken", {}).get("name"),
            "dex": best.get("dexId"),
            "pool_address": best.get("pairAddress"),
            "price_usd": float(best.get("priceUsd") or 0),
            "market_cap": float(best.get("marketCap") or best.get("fdv") or 0),
            "fdv": float(best.get("fdv") or 0),
            "liquidity_usd": float(liq.get("usd") or 0),
            "volume_5m": float(vol.get("m5") or 0),
            "volume_1h": float(vol.get("h1") or 0),
            "price_change_5m": float(pc.get("m5") or 0),
            "price_change_1h": float(pc.get("h1") or 0),
            "buys_5m": int((txns.get("m5") or {}).get("buys", 0)),
            "sells_5m": int((txns.get("m5") or {}).get("sells", 0)),
            "pair_created_at": best.get("pairCreatedAt"),
        }
