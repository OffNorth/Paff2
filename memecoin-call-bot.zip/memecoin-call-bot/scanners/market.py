"""Agrège les données de plusieurs scanners et calcule des métriques dérivées (ex: holder growth proxy)."""
import time


class MarketAggregator:
    def __init__(self, dex_scanner, birdeye_scanner=None):
        self.dex = dex_scanner
        self.birdeye = birdeye_scanner
        self._history: dict[str, list[dict]] = {}
        self._holder_history: dict[str, list[tuple[float, int]]] = {}

    async def fetch(self, mint: str) -> dict | None:
        data = await self.dex.get_token_data(mint)
        if not data:
            return None

        now = time.time()

        # Historique prix/volume/liquidité pour calculs de momentum additionnels
        hist = self._history.setdefault(mint, [])
        hist.append({"ts": now, "price": data["price_usd"], "buys": data["buys_5m"],
                      "sells": data["sells_5m"], "liq": data["liquidity_usd"]})
        cutoff = now - 3600
        self._history[mint] = [h for h in hist if h["ts"] >= cutoff]

        data["holder_growth_pct"] = None
        data["holder_growth_10m"] = 0

        # Holders réels via Birdeye si disponible
        if self.birdeye and self.birdeye.enabled:
            overview = await self.birdeye.get_token_overview(mint)
            if overview and overview.get("holders") is not None:
                hh = self._holder_history.setdefault(mint, [])
                hh.append((now, overview["holders"]))
                self._holder_history[mint] = [h for h in hh if h[0] >= now - 3600]
                window = [h for h in self._holder_history[mint] if h[0] >= now - 600]
                if len(window) >= 2 and window[0][1] > 0:
                    growth_pct = (window[-1][1] - window[0][1]) / window[0][1] * 100
                    data["holder_growth_pct"] = growth_pct
                    data["holder_growth_10m"] = max(0, growth_pct)

        # Sinon, proxy basé sur le flux net d'acheteurs (V1 sans Birdeye)
        if data["holder_growth_pct"] is None:
            recent = self._history[mint]
            if len(recent) >= 2:
                buys_delta = recent[-1]["buys"] - recent[0]["buys"]
                sells_delta = recent[-1]["sells"] - recent[0]["sells"]
                data["holder_growth_10m"] = max(0, (buys_delta - sells_delta)) * 0.5

        return data
